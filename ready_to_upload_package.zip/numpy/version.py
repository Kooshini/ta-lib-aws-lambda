
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.15.1'
version = '1.15.1'
full_version = '1.15.1'
git_revision = '5adb81051086a45fe3b59ba506b567340ec9bd5e'
release = True

if not release:
    version = full_version
